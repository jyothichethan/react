import React, { useState, useEffect } from 'react';
import { Button} from 'react-bootstrap';
import './Header.css';
import ModalFilter from '../modal/ModalFilter';

export default function Header(props) {

  const [username, setusername] = useState('');
  const [displayValue,setdisplayvalue] = useState('');

  useEffect(function()
  {
     setusername("You are Signed in as: "+ localStorage.getItem("username"));
     setdisplayvalue("block");
  }
  ,[]);
  const  logout = () =>
  {
    localStorage.clear(); 
    setusername("");
    setdisplayvalue("none");
    window.location.href = '/';
  }
  return (
    <div>
    <nav className="navbar navbar-expand-lg navbar-light bg-info">
      <div className="container-fluid">
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <div className="col-md-2 col-md-push-4">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          <li className="liClass nav-item">
            <a className="nav-link" data-testid="dashboard" id="dashboardLink" href="/dashboard" style={{color:"black"}}>DashBoard</a>
          </li>
        </ul>
        </div>
        <div className="readNowDiv col-md-6" style={{display:"inherit"}}>
          <a className="nav-link" id="readNow" style={{color:"black"}} href="/readnow">Read Now</a>
          <ModalFilter/>
        </div>
        <div className="detailsDiv col-md-4" style={{display:displayValue,textAlign:"right"}}>
          <span>{username}</span>
          <Button onClick={logout}> Sign out</Button>
        </div>
      </div>
    </div>
  </nav>
 </div>
  )
}
