import React, { Component } from 'react';
import './Footer.css'

class Footer extends Component {
    render() {
        return (
            <div className="clsfooter">
               <p style={{textAlign:"center"}}> Contact us on News Api</p>
            </div>
        )
    }
}

export default Footer;
