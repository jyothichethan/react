import React from "react";
import Newscard from "react-bootstrap/Card";

export default function Card(props) {
 
    return (
        <div className="" style={{width: "26rem"}}>
              <Newscard>
                <Newscard.Body style={{padding:"0.25rem"}}>
                  <Newscard.Img src={props.urlToImage} style={{height:"9rem"}} alt="Image Not Availablle"/>
                  <Newscard.Title >{props.title}</Newscard.Title>  
                  <Newscard.Title >{props.author}</Newscard.Title>   
                  <Newscard.Text>{props.description}</Newscard.Text>             
                  </Newscard.Body>
              </Newscard>
        </div>
    )
}