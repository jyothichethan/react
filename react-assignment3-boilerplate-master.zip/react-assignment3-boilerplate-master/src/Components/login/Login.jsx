import React, { useState } from 'react';
import axios from 'axios';
import {useHistory} from 'react-router-dom';
import './Login.css';
export default function Login() 
{
    const history=useHistory();
    const [username,setusername]=useState('');
    const [password,setpassword]=useState('');
    const submitLogin= (e) =>
    {
        e.preventDefault();
            axios.post('http://localhost:3001/auth/v1',{username,password},
            {
                headers: {
                    'Content-Type':'application/json'
                }
            }
            ).then ( 
                (res)=>
                {  
                    localStorage.setItem('token',res.data.token);
                    localStorage.setItem('isAuthenticated',"true");
                    localStorage.setItem('username',username);
                    history.push('dashboard')
                } )
            .catch( err=> 
                {
                  alert("username or password is incorrect");
                  console.log(err);
               })
    }
    
        return (
            <div>
                  <nav className="navbar navbar-expand-lg navbar-light bg-info loginDivHeader" >
                    <div className="container-fluid">
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                          <span className="navbar-toggler-icon"></span>
                        </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <div className="col-md-12">
                      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                          <a className="nav-link" href="/dashboard" style={{color:"black"}}>Routing Application News Feed   , Please Login to Continue</a>
                        </li>
                      </ul>
                      </div>
                    </div>
                  </div>
                </nav>
            <div className="col-md-4" style={{marginTop:"8px"}}>
            <div className="col-md-8 loginText"><h3 style={{marginBottom:0}}>Log In Form</h3></div>
            <form className="loginForm jumbotron" style={{padding:"2rem 2rem"}} onSubmit={ (e)=> {submitLogin(e);}}>
                <div className="m1 form-group" >
                    <label>User name</label>
                    <input type="username" className="form-control"id="username" placeholder="Enter User name"  onChange={(evt)=>setusername(evt.target.value)}/>
                </div>

                <div className="m2 form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" id="password" placeholder="Enter password" onChange={(evt)=>setpassword(evt.target.value)}/>
                </div>

                <button type="submit" id="submit" className="btn btn-dark btn-lg btn-block">Sign in</button>
                <p className="forgot-password text-right">
                    Click <a id="registerTag" href="/register">here</a> for register
                </p>
            </form>
            </div>
            </div>
        );
    }
