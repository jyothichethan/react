import React from 'react';
import axios from 'axios';
import {useState,useEffect} from 'react';
import Newscard from '../card/Card';
import Header from '../header/Header';

export default function ReadNow() {

    const [dataContent, setdataContent]=useState([ ]);

    useEffect(function()
    {
        axios.get('http://localhost:3001/api/v1/news',
        {
            headers:{'Authorization':`Bearer ${localStorage.getItem("token")}`}
        })
        .then(
         (result)=>
            {
                    console.log(result.data);
                    setdataContent(result.data);
            } 
            )
            .catch((err)=>console.log(err))
            }
        ,[]);
        return (
            <div> 
            <Header/>
            <div className="container">
            <div className="row">
            <div className="col-md-12" style={{display:"contents"}}>
            {   
                dataContent.map (
                    (dataD)=> 
                    <Newscard  key={dataD.url} urlToImage={dataD.urlToImage} title={dataD.title} author={dataD.author}
                    url={dataD.url} description={dataD.description} 
                    />
                    )
            }
           </div>
          </div>
         </div>
         </div>
        )
}
