import React,{useState,useEffect} from 'react';
import axios from 'axios';
import Card from 'react-bootstrap/Card';
import Header from '../header/Header';
export default function Dashboard(props) 
{
const [dataContent, setdataContent]=useState([ ]);
 const [displayText,setdisplaytext] = useState('');
useEffect(() => {
    let apiCall='',sourceFilter = false;
    if(props.paramsData === undefined || props.paramsData === null || props.paramsData.length === 0)
    {
        apiCall = "https://newsapi.org/v2/top-headlines?country=in&category=health&apiKey=744fdae72e614578a2a0456ded411ce2&pagesize=20&page=1"
        setdisplaytext('End Point: Top Headlines ,Country:in ,Category: health');
    }
    else{
        sourceFilter = props.paramsData.sourceFilter;                        
        apiCall = "https://newsapi.org/v2/"+props.paramsData.apiCallSet+"&apiKey=744fdae72e614578a2a0456ded411ce2&pagesize="+props.paramsData.pageSize+"&page="+props.paramsData.page;
        setdisplaytext('End Point: '+props.paramsData.endPointType);
    }
    
    axios.get(apiCall).then(
    (result)=>
        {
            if(result.data.status === "ok")
            {
                if(sourceFilter){
                    console.log(result.data.sources);
                    setdataContent(result.data.sources);
                }else{
                    console.log(result.data.articles);
                    setdataContent(result.data.articles);
                }
            }  
            else{
                console.log("Data not loaded from news api");
            }
        
        } 
        )
        .catch((err) =>console.log(err));
}, [props]);
  
const saveReadLaterDetails= (props)=>
{
    axios.post('http://localhost:3001/api/v1/news',props,
    {
        headers:{'Authorization':`Bearer ${localStorage.getItem("token")}`}
    })
    .then(
        (res)=>
        {
          console.log(res.data);
          alert("data added succesfully");
        }
    )
    .catch(
        (err)=>console.log(err)
    )
  }

    return (
        <div>
        <Header/>
        <h5>{displayText}</h5>
        <div className="container">
        <div className="row">
        <div className="col-md-12" style={{display:"contents"}}>
        {   
            dataContent.map (
                (dataD)=> 
                <div className="" style={{width: "22rem"}}>
                <Card>
                    <Card.Body >
                        <Card.Img src={dataD.urlToImage} style={{height:"9rem"}} alt=""/>
                        <Card.Title style={{fontSize: "0.7rem"}}>{dataD.title}</Card.Title>  
                        <Card.Title style={{fontSize: "0.4rem"}}>{dataD.author}</Card.Title>
                        <Card.Text  style={{fontSize: "0.4rem"}}>{dataD.url}</Card.Text>  
                        <Card.Text  style={{fontSize: "0.4rem"}}>{dataD.description}</Card.Text>               
                    </Card.Body>
                  <button className="btn btn-info" onClick={()=> saveReadLaterDetails(dataD)}>Read Later</button>
                </Card>
                </div>
                )
        }
         
       </div>
      </div>
     </div>
     </div>
    )
}