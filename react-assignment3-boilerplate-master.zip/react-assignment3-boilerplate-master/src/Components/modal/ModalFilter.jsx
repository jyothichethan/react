import React, { useEffect, useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import Tab from 'react-bootstrap/Tab';
import { Col, Row, Nav ,FormControl} from "react-bootstrap";
import InputGroup from 'react-bootstrap/InputGroup';
import { useHistory } from 'react-router';
import './ModalFilter.css'

export default function ModalFilter(props) {

      const history=useHistory();
      const [modal, setmodal] = useState('');
      const [text,settext] = useState('');
      const [countries,setcountry] = useState([]);
      const [categories,setcategories] = useState([]);
      const [textC,settextc] = useState('');
      const [searchText,setsearchtext] = useState('');
      const [searchSource,setsearchsourcetext] = useState('');
      const [apiCallType,setapicalltype] = useState('');
      const [suggestionsC,setsuggestionsc] = useState([]);
      const [suggestions,setsuggestions] = useState([]);

      useEffect(function()
      {
          setmodal(false);
          settext('');
          settextc('');
          setsearchtext('');
          setsearchsourcetext('')
          setapicalltype('top-headlines');
          setcountry(['ae','ar','at','au','be','bg','br','ca','ch','cn','co','cu','cz','de','eg','fr','gb','gr','hk','hu','id','ie','il','in','it','jp','kr','lt','lv','ma','mx', 'my' ,'ng' ,'nl' ,'no', 'nz', 'ph', 'pl', 'pt', 'ro', 'rs', 'ru', 'sa', 'se', 'sg', 'si', 'sk', 'th', 'tr', 'tw', 'ua', 'us', 've', 'za']);
          setcategories(['business','entertainment','general','health','science','sports','technology']);
      }
      ,[]);
      const toggle = () =>
      {
        setmodal(!modal);
        settext('');
        settextc('');
        setapicalltype('top-headlines');
      }
      const onValueChanged = (value) =>
      {
        console.log("value----",value);
        setapicalltype(value);
        if(value === 'everything')
        {
            settext('')
            settextc('')
            setsearchsourcetext('')
        }else if(value === 'sources')
        {
          settext('')
          settextc('')
          setsearchtext('');
        }else
        {
          setsearchtext('');
          setsearchsourcetext('')
        }
      }
      const onChange = (e) =>{
        setsearchtext(e.target.value);
      }
      const onChangeS = (e) =>{
        setsearchsourcetext(e.target.value);
      }
      const onTextChanged = (e) =>
      {
        let value=e.target.value;
        let suggestions = [];
        if(value.length >0 ){
            const regex = new RegExp(`${value}`,'i');
            suggestions = countries.sort().filter(v => regex.test(v));
        }
        setsuggestions(suggestions);
        settext(value);
      }
      const suggestionsSelected = (value) =>
      {
        settext(value);
        setsuggestions([]);
      }
      const renderSuggestions = () => {
          if(suggestions.length === 0){
            return null;
          }
          return (
              <ul>
                {suggestions.map((item) => <li onClick={() => suggestionsSelected(item)}>{item}</li>)}
              </ul>
          );
      }
      const onTextChangedC = (e) =>
      {
        let value=e.target.value;
        let suggestions = [];
        if(value.length >0 ){
            const regex = new RegExp(`${value}`,'i');
            suggestions = categories.sort().filter(v => regex.test(v));
        }
        setsuggestionsc(suggestions);
        settextc(value);
      }
      const suggestionsSelectedC = (value) =>
      {
        settextc(value);
        setsuggestionsc([]);
      }
      const renderSuggestionsC = () => {
          if(suggestionsC.length === 0){
            return null;
          }
          return (
              <ul>
                {suggestionsC.map((item) => <li onClick={() => suggestionsSelectedC(item)}>{item}</li>)}
              </ul>
          );
      }
      const handleSubmit = (event) => 
      {
        event.preventDefault();
        let country = event.target[1].value;
        let category = event.target[2].value;
        let search = event.target[3].value;
        let searchSource = event.target[4].value;
        let pageSize=event.target[5].value;
        let page=event.target[6].value;
        let data = '',apiCallSet = '',sourceFilter = false,endPointType = '';
        if(apiCallType === 'top-headlines'){
          endPointType= 'Top Headlines'
           if(country != null && category != null)
           {
               apiCallSet = apiCallType+"?country="+country+"&category="+category;
               endPointType+= " ,Country: "+country+" ,Category: "+category;
           }else if(country != null && category === null){
               apiCallSet = apiCallType+"?country="+country;
               endPointType+= " , Country: "+country;
           }else{
               apiCallSet = apiCallType+"?category="+category;
               endPointType+= " , Category: "+category
           }
        }else if(apiCallType === 'everything')
        {
          endPointType= 'Everything'
          if(search != null){
            apiCallSet = apiCallType+"?q="+search;
            endPointType+= " , Search Text: "+search
          }
          else{
            apiCallSet = apiCallType
          }
        }else{
          endPointType= 'Sources'
          if(searchSource != null){
            apiCallSet = apiCallType+"?sources="+searchSource;
            endPointType+= " , Sources: "+searchSource
            sourceFilter = true;
          }else{
            apiCallSet = apiCallType
            sourceFilter = true;
          }
        }
        data =JSON.stringify({apiCallSet,pageSize,page,sourceFilter,endPointType})
        setmodal(false);
        history.push({
          pathname: '/filter',
          state: data
        });
      }
        return (
                  <div className="btnDiv">
                    <Button className="" id="filterButton" style={{color:"black",fontWeight:"bold"}}  onClick={toggle}>Filter</Button>
                      <Modal show={modal} size="lg" >
                        <form onSubmit={handleSubmit}>
                          <Modal.Header closeButton>
                            <Modal.Title>Filter based NEWS API Data Source</Modal.Title>
                          </Modal.Header>
                          <Modal.Body>
                              <h5> End Points </h5>
                              <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                                <Row>
                                  <Col sm={3}>
                                    <Nav variant="pills" className="tabDiv flex-column">
                                      <Nav.Item className="first">
                                        <Nav.Link eventKey="first"  onClick={() => onValueChanged('top-headlines')}>Top Headlines</Nav.Link>
                                      </Nav.Item>
                                      <Nav.Item className="second"> 
                                        <Nav.Link eventKey="second" onClick={() => onValueChanged('everything')}>Everything</Nav.Link>
                                      </Nav.Item>
                                      <Nav.Item className="third">
                                        <Nav.Link eventKey="third" onClick={() => onValueChanged('sources')}>Sources</Nav.Link>
                                      </Nav.Item>
                                    </Nav>
                                  </Col>
                                  <Col sm={9}>
                                    <Tab.Content>
                                      <Tab.Pane eventKey="first">
                                      <div className="App-Component">
                                        <div className="AutoComplete">
                                          <InputGroup className="mb-3">
                                            <InputGroup.Prepend>
                                              <InputGroup.Text id="inputGroup-sizing-default">Country</InputGroup.Text>
                                            </InputGroup.Prepend>
                                            <FormControl
                                               aria-label="Default"
                                               aria-describedby="inputGroup-sizing-default"
                                               id="country"
                                               value={text}
                                               onChange={onTextChanged}
                                            />
                                          </InputGroup>
                                          <div className="ulDiv">
                                              {renderSuggestions()}
                                          </div>
                                        </div>
                                          <InputGroup className="mb-3">
                                              <InputGroup.Prepend>
                                                <InputGroup.Text id="inputGroup-sizing-default">Category</InputGroup.Text>
                                            </InputGroup.Prepend>
                                            <FormControl
                                              aria-label="Default"
                                              aria-describedby="inputGroup-sizing-default"
                                              value={textC}
                                              onChange={onTextChangedC}
                                              id="category"
                                            />
                                          </InputGroup>
                                       <div className="ulDiv">
                                         {renderSuggestionsC()}
                                       </div>
                                      </div>
                                    </Tab.Pane>
                                    <Tab.Pane eventKey="second">
                                      <div>
                                        <InputGroup className="mb-3">
                                          <InputGroup.Prepend>
                                            <InputGroup.Text id="inputGroup-sizing-default">Search text</InputGroup.Text>
                                          </InputGroup.Prepend>
                                          <FormControl
                                            aria-label="Default"
                                            aria-describedby="inputGroup-sizing-default"
                                            id="search"
                                            value={searchText}
                                            onChange={onChange}
                                          />
                                         </InputGroup>
                                      </div>
                                    </Tab.Pane>
                                    <Tab.Pane eventKey="third">
                                      <div>
                                        <InputGroup className="mb-3">
                                          <InputGroup.Prepend>
                                            <InputGroup.Text id="inputGroup-sizing-default">Sources(, seperated)</InputGroup.Text>
                                          </InputGroup.Prepend>
                                          <FormControl
                                                aria-label="Default"
                                                aria-describedby="inputGroup-sizing-default"
                                                id="sources"
                                                value={searchSource}
                                                onChange={onChangeS}
                                          />
                                       </InputGroup>
                                      </div>
                                    </Tab.Pane>
                                  </Tab.Content>
                                </Col>
                            </Row>
                          </Tab.Container>
                        <div>
                          <InputGroup className="mb-3">
                                <InputGroup.Prepend>
                                  <InputGroup.Text id="inputGroup-sizing-default">Page Size</InputGroup.Text>
                                </InputGroup.Prepend>
                                <FormControl
                                        aria-label="Default"
                                        aria-describedby="inputGroup-sizing-default" 
                                        value="20"
                                />
                            </InputGroup>
                            <InputGroup className="mb-3">
                                <InputGroup.Prepend>
                                  <InputGroup.Text id="inputGroup-sizing-default">Page</InputGroup.Text>
                                </InputGroup.Prepend>
                                <FormControl
                                        aria-label="Default"
                                        aria-describedby="inputGroup-sizing-default"
                                        value="1"
                                />
                            </InputGroup>
                        </div>
                      </Modal.Body>
                      <Modal.Footer>
                        <input type="submit" value="Submit" color="primary" className="btn btn-primary" />
                        <Button variant="secondary" onClick={toggle}>Cancel</Button>
                      </Modal.Footer>
                    </form>
                 </Modal>
            </div>
    )
}

