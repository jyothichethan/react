import React, { Component } from 'react';

class NotFound extends Component {
    render() {
        return (
            <div className="col-md-6">
                <h1>The Requested Url not found</h1>
            </div>
        );
    }
}

export default NotFound;