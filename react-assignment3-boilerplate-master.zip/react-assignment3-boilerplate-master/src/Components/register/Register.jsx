import React, { Component } from 'react';
import '../login/Login.css'
class Register extends Component {
    render() {
        return (
            <div>
                  <nav className="navbar navbar-expand-lg navbar-light bg-info loginDivHeader" >
                    <div className="container-fluid">
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                          <span className="navbar-toggler-icon"></span>
                        </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <div className="col-md-12">
                      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                          <a className="nav-link" href="/dashboard" style={{color:"black"}}>Routing Application News Feed   , Please Register and Login to Continue</a>
                        </li>
                      </ul>
                      </div>
                    </div>
                  </div>
                </nav>
            <div className="col-md-4" style={{marginTop:"8px"}}>
                 <div className="col-md-8 loginText"><h3 style={{marginBottom:0}}>Register Form</h3></div>
                <form className="jumbotron" style={{padding:"2rem 2rem"}} >

                    <div className="form-group">
                        <label>First name</label>
                        <input type="text" className="form-control" placeholder="First name" />
                    </div>

                    <div className="form-group">
                        <label>Last name</label>
                        <input type="text" className="form-control" placeholder="Last name" />
                    </div>

                    <div className="form-group">
                        <label>Email</label>
                        <input type="email" className="form-control" placeholder="Enter email" />
                    </div>

                    <div className="form-group">
                        <label>Password</label>
                        <input type="password" className="form-control" placeholder="Enter password" />
                    </div>

                    <button type="submit" className="btn btn-dark btn-lg btn-block">Register</button>
                    <p className="forgot-password text-right">
                        Already registered <a id="backLogin" href="/">log in?</a>
                    </p>
            </form>
        </div>
        </div>
        );
    }
}

export default Register;