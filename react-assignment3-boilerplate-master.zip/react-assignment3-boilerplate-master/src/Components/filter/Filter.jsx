import React from 'react'
import Dashboard from '../dashboard/Dashboard'

export default function Filter(props) {
    console.log("props------"+props);
    return (
        <div>
            <Dashboard paramsData={JSON.parse(props.location.state)}/>
        </div>
    )
}
