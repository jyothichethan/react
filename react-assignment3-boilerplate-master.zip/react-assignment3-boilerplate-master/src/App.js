import React from 'react';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/login/Login';
import Footer from './Components/footer/Footer';
import Register from './Components/register/Register';
import Dashboard from './Components/dashboard/Dashboard';
import ReadNow from './Components/readNow/ReadNow';
import PrivateRoute from './PrivateRoute';
import NotFound from './Components/NotFound';
import Filter from './Components/filter/Filter'

class App extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {isLoggedin : false}
  }

  render(){
  return(
    <div className="app">
    <Router> 
       <Switch>
            <Route exact path="/" component={Login}/>
            <PrivateRoute  path="/dashboard" component={Dashboard}/>
            <PrivateRoute path="/filter" component={Filter}/>
            <Route path="/register" component={Register}/>
            <PrivateRoute path="/readnow" component={ReadNow}/> 
            <Route component={NotFound}/>         
       </Switch>
    <Footer/>
    </Router>
    </div>
  )
  }

}
export default App;
